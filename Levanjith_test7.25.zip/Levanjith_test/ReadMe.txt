Laravel framework 
php 7.0
Laravel Installer 2.1.0
database name - php_dev_levanjith

composer update then run the project php artisan serve