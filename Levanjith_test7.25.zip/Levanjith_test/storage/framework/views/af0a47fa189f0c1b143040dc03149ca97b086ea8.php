<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/postupdate')); ?>" method="Post">

<div class="container">
        

<?php $__currentLoopData = $editdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<input id="ids" type="text" hidden  name="id"  value="<?php echo e($value->id); ?>"  class="form-control" >


                
  <div class="col-md-12">
  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="last_name">First name</label>
        <input id="fname" class="form-control input-cl" required type="text" name="fname" value="<?php echo e($value->fname); ?>">
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group">
        <label for="from">D S Divition</label>
          
          <select class="form-control input-cl" required  id="divition" name="divition">
            <option value="" selected>select..</option>
            <option value="Colombo1">Colombo 1</option>
            <option value="Colombo2">Colombo 2</option>
            <option value="Colombo3">Colombo 3</option>
            <option value="Colombo4">Colombo 4</option>
            <option value="Colombo5">Colombo 5</option>
            <option value="Colombo6">Colombo 6</option>
            <option value="Colombo7">Colombo 7</option>
            <option value="Colombo8">Colombo 8</option>
            <option value="Colombo9">Colombo 9</option>
            <option value="Colombo10">Colombo 10</option>
            </select>
      </div>
    </div>
   </div>
  </div>


  <div class="col-md-12">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="from">last name</label>
          <input id="lname" class="form-control input-cl" required type="text" name="lname" value="<?php echo e($value->lname); ?>">
        </div>
      </div>
    <div class="col-md-6">
      <div class="form-group">
        <label for="from">Date of Birth</label>
        <input id="dob" class="form-control input-cl" required type="text" name="dob" value="<?php echo e($value->dob); ?>">
      </div>
    </div>
  </div>
  </div>



          <div class="col-md-12">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="from">Summery</label><br>
                  <input id="summery"  class="form-control input-cl" type="text" name="summery" value="<?php echo e($value->summery); ?>">
                </div>
              </div>
            <div class="col-md-6">

            </div>
          </div>
          </div>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br><br><br>

          <div class="modal-footer">
                <button class="btn btn-success"   type="submit"  >Update</button>

                
           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>


      </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\localhost\TEST\Levanjith_test\resources\views/php/update.blade.php ENDPATH**/ ?>