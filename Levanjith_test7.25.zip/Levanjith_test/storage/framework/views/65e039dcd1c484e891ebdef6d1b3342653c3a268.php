<?php $__env->startSection('content'); ?>
<?php echo $__env->make('module.editmodle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">



<div class="container">

  <h2>Accura Member List</h2><br><br>
  <a href="<?php echo e(url('phptable')); ?>"  class="addmem btn btn-primary">Php Table</a>
  <a href="<?php echo e(url('home')); ?> "class="addmem btn btn-primary">Add New Member</a><br>
  <div class="topnav"><br>
    <p>Serch</a>
    
    <form action="/phptable" method="GET">
      <input type="text" placeholder="Search.." name="search" />
      <input type="submit" value="Go" />
  </form>

    <form action="/multiserch" method="GET">
      <div class="com-md-12">    
        <select   name="fname" >  
          <option></option>
        <?php $__currentLoopData = $typesr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option><?php echo e($value->fname); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>      
      
    </div>
      <div class="com-md-12">
        <select   name="status" >  
          
          <option></option>
          <?php foreach ($typesr as $srow): ?>
          <option value="<?php print $srow['id']; ?>" ><?php print $srow['member_status_id']; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
  

    
    <input type="submit" value="Go" />
 </form>

  </div> 
  <table id="view_table"  class="table table-striped table-bordered view_table" style="width: 100%;">
    <thead class="thead-dark">
      <tr >
        <td>#</td>
        <td> <a href="<?php echo e(url('shortby_fname')); ?>"  >ShortBy_Name</a></td>
        <td> <a href="<?php echo e(url('shortby_lname')); ?>"  >ShortBy_Lname</a></td>
        <td> <a href="<?php echo e(url('shortby_divition')); ?>"  >ShortBy_Divition</a></td>
        <td> <a href="<?php echo e(url('shortby_dob')); ?>"  >ShortBy_dob</a></td>
        <td> <a href="<?php echo e(url('phptable')); ?>/?name=aaa"  >aaa</a></td>
        <td></td>
      </tr>
        <tr>
          <th>#</th>
          <th>fname</th>
          <th>lname</th>
          <th>divition</th>
          <th>dob</th>
          <th>summery</th>
          <th>action</th>
        </tr>
      </thead>
  
            <tbody  class="tbody-light">
              <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($value->id); ?></td>
              <td><?php echo e($value->fname); ?></td>
              <td><?php echo e($value->member_status->name); ?></td>
              <td><?php echo e($value->divition); ?></td>
              <td><?php echo e($value->member_status_id); ?></td>
              <td><?php echo e($value->summery); ?></td>  
                <td><?php echo e($value->image); ?></td>  
              <td><a class="btn btn-primary btn-edit" type="submit"  href="newedit/<?php echo e($value->id); ?>" >Edit</a>
                 <a class="btn btn-danger btn-delete"  type="submit"   href="newdel/<?php echo e($value->id); ?>" >Delete</a> </td>
              </tr>                                                                                                                        
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    
          </tbody>
        </table>
        
        
</div>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js" charset="utf-8"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js" charset="utf-8"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\localhost\TEST\Levanjith_test\resources\views/php/table.blade.php ENDPATH**/ ?>