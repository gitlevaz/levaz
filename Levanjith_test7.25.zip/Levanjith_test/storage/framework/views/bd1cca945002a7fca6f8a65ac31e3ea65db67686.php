<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
<link rel="stylesheet"  href="<?php echo e(asset('css/main.css')); ?>">


</head>
<body>
    
        <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-4 section_main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    
</body>
</html>
<?php /**PATH E:\localhost\TEST\Levanjith_test\resources\views/layouts/app.blade.php ENDPATH**/ ?>